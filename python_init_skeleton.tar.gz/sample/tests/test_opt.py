#!/usr/bin/env python
# -*- coding: UTF-8 -*-

#  FileName  :  test_opt.py
# Last Change:  2015年10月10日
#   AUTHOR   :  BaiLiang , bailiangcn@gmail.com

"""
测试opt.py模块
"""

__revision__ = '0.1'

import sys
import os

CUR_DIR = os.path.abspath(os.path.dirname(__file__))
PAR_DIR = os.path.abspath(os.path.join(CUR_DIR, os.path.pardir))

sys.path.append(os.path.abspath(PAR_DIR))
sys.path.append(os.path.abspath(CUR_DIR))

import opt

from unittest import TestCase


class simpleTest(TestCase):
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_Sum(self):
        self.assertEqual(opt.sum(0, 1), 1)


if '__main__' == __name__:
    import unittest
    unittest.main()
# vim:ts=4:sw=4:ft=python:expandtab:set fdm=indent:
