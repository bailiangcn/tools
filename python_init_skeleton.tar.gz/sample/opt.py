#!/usr/bin/env python
# -*- coding: UTF-8 -*-

#  FileName  :  opt.py
# Last Change:  2015年10月10日
#   AUTHOR   :  BaiLiang , bailiangcn@gmail.com

"""
    调整交换机参数
"""


def sum(x, y):
    return x + y


def main():
    print "Hello"


if __name__ == "__main__":
    main()

# vim:ts=4:sw=4:ft=python:expandtab:set fdm=indent:
