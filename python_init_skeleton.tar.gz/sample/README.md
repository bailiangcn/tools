<meta http-equiv="content-type" content="text/html; charset=UTF-8">


网络调整项目
=======================

## 1、项目目的

>  为了方便调整交换机，制作本脚本

## 2、文件功能说明

        opt.py  　　主功能文件

        alltest.py　　单元测试





